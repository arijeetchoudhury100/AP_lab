function count = insertionSort(arr)
  n = length(arr);
  count = 0;
  for i = 2:n
    j = i-1;
    key = arr(i);
    while j>=1
      count = count+1;
      if arr(j)<=key
        break;
      end
      arr(j+1)=arr(j);
      j=j-1;
    end
    arr(j+1)=key;
  end
end
