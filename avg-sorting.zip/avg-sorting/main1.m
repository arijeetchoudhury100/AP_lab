%for random input
bubbler = zeros(1,10);
insertionr = zeros(1,10);
selectionr = zeros(1,10);
quickr = zeros(1,10);
count1r = zeros(1,10);
count2r = zeros(1,10);
count3r = zeros(1,10);
count4r = zeros(1,10);

%for nearly sorted input
bubbles = zeros(1,10);
insertions = zeros(1,10);
selections = zeros(1,10);
quicks = zeros(1,10);
count1s = zeros(1,10);
count2s = zeros(1,10);
count3s = zeros(1,10);
count4s = zeros(1,10);

%for reverse sorted input
bubblers = zeros(1,10);
insertionrs = zeros(1,10);
selectionrs = zeros(1,10);
quickrs = zeros(1,10);
count1rs = zeros(1,10);
count2rs = zeros(1,10);
count3rs = zeros(1,10);
count4rs = zeros(1,10);


elements = zeros(1,10);
k=1;
for i=10:10:100
  elements(k) = i;
  for j=1:10
    a = round(rand(1,i)*100);
    b = flip(sort(round(rand(1,i)*100)));
    c = sort(round(rand(1,i)*100));
    i1=rem((round(rand()*100)),i)+1;
    i2=rem((round(rand()*100)),10)+1;
    temp=c(i1);
    c(i1)=c(i2);
    c(i2)=temp;
    
    count1r(j) = bubbleSort(a);
    count2r(j) = insertionSort(a);
    count3r(j) = selectionSort(a);
    count4r(j) = quickSort(a);
    
    count1rs(j) = bubbleSort(b);
    count2rs(j) = insertionSort(b);
    count3rs(j) = selectionSort(b);
    count4rs(j) = quickSort(b);
    
    count1s(j) = bubbleSort(c);
    count2s(j) = insertionSort(c);
    count3s(j) = selectionSort(c);
    count4s(j) = quickSort(c);
  end
  bubbler(k) = mean(count1r);
  insertionr(k) = mean(count2r);
  selectionr(k) = mean(count3r);
  quickr(k) = mean(count4r);
  
  bubblers(k) = mean(count1rs);
  insertionrs(k) = mean(count2rs);
  selectionrs(k) = mean(count3rs);
  quickrs(k) = mean(count4rs);
  
  bubbles(k) = mean(count1s);
  insertions(k) = mean(count2s);
  selections(k) = mean(count3s);
  quicks(k) = mean(count4s);
  k = k+1;
end
figure("1");
plot(elements,bubbler,elements,insertionr,elements,selectionr,elements,quickr);
title('Random input');
xlabel('no of elements');
ylabel('no of comparisons');
legend('bubble sort','insertion sort','selection sort','quick sort');

figure("2");
plot(elements,bubblers,elements,insertionrs,elements,selectionrs,elements,quickrs);
title('Reverse ordered input');
xlabel('no of elements');
ylabel('no of comparisons');
legend('bubble sort','insertion sort','selection sort','quick sort');

figure("3");
plot(elements,bubbles,elements,insertions,elements,selections,elements,quicks);
title('Nearly sorted');
xlabel('no of elements');
ylabel('no of comparisons');
legend('bubble sort','insertion sort','selection sort','quick sort');
  
  