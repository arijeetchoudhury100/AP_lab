function count = bubbleSort(arr)
  n = length(arr);
  count = 0;
  swapped = 0;
  for i=1:n-1
    for j=1:n-i
      count = count+1;
      if arr(j)>arr(j+1)
        temp = arr(j);
        arr(j) = arr(j+1);
        arr(j+1) = temp;
      end
    end
  end
end

      