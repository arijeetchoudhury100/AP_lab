function count = mergeSort(arr)
  count = 0;
  count = mergesort(arr,count);
  disp(count);
end

function [res,count] = mergesort(arr,count)
  res=[];
  n = length(arr);
  if n<2
    res=arr;
    return;
  end
  mid=int64(n/2);
  [left,count]=mergesort(arr(1:mid),count);
  [right,count]=mergesort(arr(mid+1:n),count);
  
  n1=length(left);
  n2=length(right);
  
  i=1;
  j=1;
  
  while i<=n1 & j<=n2
    count=count+1;
    if left(i)<right(j)
      res=[res left(i)];
      i=i+1;
    else
      res=[res right(j)];
      j=j+1;
    end
  end
  while i<=n1
    res=[res left(i)];
    i=i+1;
  end
  while j<=n2
    res=[res right(j)];
    j=j+1;
  end
  
end
