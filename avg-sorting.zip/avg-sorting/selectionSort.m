function count = selectionSort(arr)
  n = length(arr);
  count = 0;
  for i = 1:n
    min = i;
    for j = (i+1):n
      count = count+1;
      if arr(j) < arr(min)
        min = j;
      end
    end
    temp = arr(i);
    arr(i) = arr(min);
    arr(min) = temp;
  end
end
