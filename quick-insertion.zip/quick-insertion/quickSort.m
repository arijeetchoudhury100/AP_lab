function count = quickSort(arr)
  count = 0;
  n = length(arr);
  [arr count] = quicksort(arr,1,n,count);
end

function [arr,count] = quicksort(arr,low,high,count)
  if low<high
    [arr,p,count] = partition(arr,low,high,count);
    [arr,count] = quicksort(arr,low,p-1,count);
    [arr,count] = quicksort(arr,p+1,high,count);
  end
end

  
  