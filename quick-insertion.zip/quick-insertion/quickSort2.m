function count = quickSort2(arr)
  count = 0;
  n = length(arr);
  [arr count] = quicksort(arr,1,n,count);
end

function [arr,count] = quicksort(arr,low,high,count)
    [arr,p,count] = partition(arr,low,high,count);
    
    if (p-low)<=12
      [arr,count] = insertionSort(arr,low,p-1,count);
    else
      [arr,count] = quicksort(arr,low,p-1,count);
    end
      
    if (high-p)<=12
      [arr,count] = insertionSort(arr,p+1,high,count);
    else
      [arr,count] = quicksort(arr,p+1,high,count);
    end    
end

function [arr,p,count] = partition(arr,low,high,count)
  pivot = arr(high);
  i = low-1;
  for j=low:(high-1)
    count=count+1;
    if arr(j)<=pivot
      i=i+1;
      temp=arr(j);
      arr(j)=arr(i);
      arr(i)=temp;
    end
  end
  temp=arr(i+1);
  arr(i+1)=arr(high);
  arr(high)=temp;
  p=i+1;
end



  
  