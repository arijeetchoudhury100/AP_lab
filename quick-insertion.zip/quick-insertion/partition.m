function [arr,p,count] = partition(arr,low,high,count)
  pivot = arr(high);
  i = low-1;
  for j=low:(high-1)
    count=count+1;
    if arr(j)<=pivot
      i=i+1;
      temp=arr(j);
      arr(j)=arr(i);
      arr(i)=temp;
    end
  end
  temp=arr(i+1);
  arr(i+1)=arr(high);
  arr(high)=temp;
  p=i+1;
end
