elements=zeros(1,50);
quick=zeros(1,50);
quickinsert = zeros(1,50);
k=1;
for n=10:20:1000
    elements(k)=n;
    q = 0;
    qi = 0;
    for i=1:10
        a=round(rand(1,n)*100);
        b=a;
        q = q + quickSort(a);
        qi = qi + quickSort2(b);
    end
    quick(k) = q/10;
    quickinsert(k) = qi/10;
    k=k+1;
end
plot(elements,quick,elements,quickinsert);
title('Quick sort variants');
xlabel('No. of elements');
ylabel('No. of comparisons');
legend('Quick sort','Quick sort/insertion sort');
grid on;