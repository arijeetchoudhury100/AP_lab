function [arr,count] = insertionSort(arr,low,high,count)
  n = length(arr);
  for i = (low+1):high
    j = i-1;
    key = arr(i);
    while j>=low
      count = count+1;
      if arr(j)<=key
        break;
      end
      arr(j+1)=arr(j);
      j=j-1;
    end
    arr(j+1)=key;
  end
end
