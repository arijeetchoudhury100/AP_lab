elements = zeros(1,10); %will store no. of elements for each test case
counts1 = zeros(1,10); %will store no. of comparisons for each test case for 1st algo
counts2 = zeros(1,10); %will store no. of comparisons for each test case for 2nd algo
j=1;

for i=10:10:100
  a = round(rand(1,i)*100); %generate a random array of size i
  elements(j) = i;
  counts1(j) = bubbleSort1(a,length(a)); %get no. of comparisons
  counts2(j) = bubbleSort2(a,length(a));
  j = j+1;
end

plot(elements,counts1);
hold on;
plot(elements,counts2);
legend('original','optimal');
title('Bubble Sort');
xlabel('No. of elements');
ylabel('No. of comparisons');
