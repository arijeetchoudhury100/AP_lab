function count = bubbleSort2(a,n)
  count = 0;
  swapped = 0;
  
  for i=1:n
    swapped = 0;
    for j=1:n-i
      count = count+1;
      if a(j)>a(j+1)
        temp = a(j);
        a(j) = a(j+1);
        a(j+1) = temp;
        swapped = 1;
      end
    end
    if swapped == 0
      break;
  end
end
