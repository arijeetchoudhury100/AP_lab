function count = bubbleSort1(a,n)
  count = 0; %%% find total number of comparisons in bubble sort..
  for i=1:n
    for j=1:n-i
      count = count+1;
      if a(j)>a(j+1)
        temp = a(j);
        a(j) = a(j+1);
        a(j+1) = temp;
      end
    end
  end
end
