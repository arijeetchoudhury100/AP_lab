num_experiments = round(rand()*1000); %number of experiments
num_flips = round(rand()*1000000);  %number of tosses per experiment

experiment = zeros(1,num_experiments);
prob_heads = zeros(1,num_experiments);

for i=1:num_experiments
  toss = round(rand(1,num_flips)); %1 represents head, 0 represents tail
  num_heads = length(find(toss));
  prob_heads(i) = num_heads/num_flips;
  experiment(i)=i;
end

disp(mean(prob_heads));
plot(experiment,prob_heads);
xlabel('experiment');
ylabel('probability of head');
title('coin toss');